
module.exports = {
  content: ["./pages/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        anko: ['Anko', 'sans-serif']
      },
      colors: {
        primary: '#00796B',
        secondary: '#FF6F00'
      }
    },
  },
  plugins: [],
};
