
import React, { useState } from 'react';
import Head from 'next/head';

const questions = [
  { id: 1, question: "How would you describe your skin type?", options: ["Oily", "Dry", "Combination", "Normal", "Sensitive"] },
  { id: 2, question: "What are your top skin concerns?", options: ["Acne", "Hyperpigmentation", "Fine lines & wrinkles", "Redness", "Texture", "Dryness"] },
  { id: 3, question: "How does your skin feel throughout the day?", options: ["Tight", "Normal", "Oily in areas", "Super oily", "Fluctuates"] },
  { id: 4, question: "What’s your skincare experience level?", options: ["Beginner", "Intermediate", "Pro"] },
  { id: 5, question: "How much time do you want to spend on your skincare routine?", options: ["Minimal (2-3 steps)", "Balanced (4-5 steps)", "Give me the full experience (6+ steps)"] },
  { id: 6, question: "What's your ideal budget per product?", options: ["Budget ($10-$25)", "Mid-Range ($25-$50)", "Premium ($50-$100)", "Luxury ($100+)"] },
  { id: 7, question: "Do you have any ingredient preferences?", options: ["Fragrance-Free", "Vegan", "Cruelty-Free", "Clean Beauty", "No Preference"] },
  { id: 8, question: "How sensitive is your skin to new products?", options: ["Very Sensitive", "Mildly Sensitive", "Not Sensitive"] },
  { id: 9, question: "What’s your environment like?", options: ["Hot + Humid", "Cold + Dry", "Mixed", "Indoor controlled"] },
  { id: 10, question: "What’s your skincare goal in 3 months?", options: ["Clear acne", "Fade dark spots", "Reduce fine lines", "Hydrate + Glow", "Calm redness"] }
];

export default function Home() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);
  const [routine, setRoutine] = useState(null);

  const handleAnswer = (answer) => {
    const questionId = questions[currentQuestion].id;
    setAnswers({ ...answers, [questionId]: answer });

    if (currentQuestion + 1 < questions.length) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      submitAnswers({ ...answers, [questionId]: answer });
    }
  };

  const submitAnswers = async (finalAnswers) => {
    try {
      const res = await fetch("/api/quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(finalAnswers)
      });
      const data = await res.json();
      setRoutine(data);
      setShowResults(true);
    } catch (error) {
      console.error("Error submitting quiz:", error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center font-anko p-6 bg-[#FDFCFB]">
      <Head>
        <link href="https://fonts.googleapis.com/css2?family=Anko&display=swap" rel="stylesheet" />
      </Head>
      {!showResults ? (
        <>
          <h1 className="text-3xl font-bold mb-6">NeuraGlow Skincare Quiz</h1>
          <div className="w-full max-w-md bg-white rounded-2xl p-8 shadow-lg border border-[#EAEAEA]">
            <h2 className="text-xl font-semibold mb-4">{questions[currentQuestion].question}</h2>
            <div className="flex flex-col space-y-4">
              {questions[currentQuestion].options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswer(option)}
                  className="w-full py-3 bg-[#E0F7FA] text-[#00796B] rounded-xl hover:bg-[#B2EBF2] transition"
                >
                  {option}
                </button>
              ))}
            </div>
            <p className="text-sm text-gray-500 mt-4">Question {currentQuestion + 1} of {questions.length}</p>
          </div>
        </>
      ) : (
        <>
          <h1 className="text-3xl font-bold mb-6">Your Personalized NeuraGlow Routine</h1>
          {Object.entries(routine).map(([step, data], idx) => (
            <div key={idx} className="w-full max-w-md bg-white rounded-2xl p-4 mb-6 shadow-lg border border-[#EAEAEA]">
              <h2 className="text-xl font-semibold mb-4">{step}</h2>
              <div className="p-4">
                <h3 className="font-bold text-lg">{data.primary["Product Name"]}</h3>
                <p className="text-sm">{data.primary["Skin Concern"]}</p>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
