
import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  const userAnswers = req.body;
  const filePath = path.join(process.cwd(), 'data', 'products_database.json');
  const fileContents = fs.readFileSync(filePath, 'utf8');
  const products = JSON.parse(fileContents);

  const sensitivityMap = {
    'Very Sensitive': ['Low'],
    'Mildly Sensitive': ['Low', 'Moderate'],
    'Not Sensitive': ['Low', 'Moderate', 'High']
  };

  const allowedSensitivity = sensitivityMap[userAnswers.sensitivity] || ['Low', 'Moderate', 'High'];
  const routine = {};
  const uniqueSteps = [...new Set(products.map((p) => p.Step))];

  uniqueSteps.forEach((step) => {
    const stepProducts = products.filter((p) =>
      p.Step === step &&
      p['Skin Type'].toLowerCase().includes(userAnswers.skin_type.toLowerCase())
    );

    if (stepProducts.length > 0) {
      const [primary, ...alternatives] = stepProducts;
      routine[step] = { primary, alternatives };
    } else {
      routine[step] = { primary: {}, alternatives: [] };
    }
  });

  res.status(200).json(routine);
}
